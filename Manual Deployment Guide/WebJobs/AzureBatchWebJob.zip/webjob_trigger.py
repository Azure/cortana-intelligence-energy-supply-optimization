import datetime
import os
import sys
import time
sys.path.append('.')
sys.path.append('..')
sys.path.append("D:\\home\\site\\wwwroot\\site-packages")
import azure.storage.blob as azureblob
import azure.storage.queue as azurequeue

import azure.batch.batch_service_client as batch
import azure.batch.batch_auth as batchauth
import azure.batch.models as batchmodels
import common.helpers  # noqa

#linux
_POOL_VM_SIZE = 'Standard_D4_v3'
_NODE_OS_PUBLISHER = 'Canonical'
_NODE_OS_OFFER = 'UbuntuServer'
_NODE_OS_SKU = '18.04-LTS'



def print_batch_exception(batch_exception):

    print('-------------------------------------------')
    print('Exception encountered:')
    if batch_exception.error and \
            batch_exception.error.message and \
            batch_exception.error.message.value:
        print(batch_exception.error.message.value)
        if batch_exception.error.values:
            print()
            for mesg in batch_exception.error.values:
                print('{}:\t{}'.format(mesg.key, mesg.value))
    print('-------------------------------------------')


def locate_blob_in_container(block_blob_client, container_name, blob_name):
 
    sas_token = block_blob_client.generate_blob_shared_access_signature(
        container_name,
        blob_name,
        permission=azureblob.BlobPermissions.READ,
        expiry=datetime.datetime.utcnow() + datetime.timedelta(hours=1))

    sas_url = block_blob_client.make_blob_url(container_name,
                                              blob_name,
                                              sas_token=sas_token)

    return batchmodels.ResourceFile(file_path=blob_name,
                                    blob_source=sas_url)


def get_container_sas_token(block_blob_client,
                            container_name, blob_permissions):

    # Obtain the SAS token for the container, setting the expiry time and
    # permissions. In this case, no start time is specified, so the shared
    # access signature becomes valid immediately.
    container_sas_token = \
        block_blob_client.generate_container_shared_access_signature(
            container_name,
            permission=blob_permissions,
            expiry=datetime.datetime.utcnow() + datetime.timedelta(hours=2))

    return container_sas_token


def create_pool(batch_service_client, pool_id, pool_node_count,
                resource_files, publisher, offer, sku):

    print('Creating pool [{}]...'.format(pool_id))

    # Specify the commands for the pool's start task. The start task is run
    # on each node as it joins the pool, and when it's rebooted or re-imaged.
    # We use the start task to prep the node for running our task script.
    task_commands = [
        # Copy the python scripts to the "shared" directory
        # that all tasks that run on the node have access to.
        'apt-get update && apt-get upgrade -y;apt-get install -y python-pip;apt-get install -y coinor-cbc;echo $AZ_BATCH_TASK_WORKING_DIR; echo $AZ_BATCH_NODE_SHARED_DIR; cp -r $AZ_BATCH_TASK_WORKING_DIR $AZ_BATCH_NODE_SHARED_DIR; pip install pyomo;pip install pandas;sudo apt-get install -y unixodbc-dev;pip install pyodbc;sudo su;curl https://packages.microsoft.com/keys/microsoft.asc | apt-key add -;curl https://packages.microsoft.com/config/ubuntu/18.04/prod.list > /etc/apt/sources.list.d/mssql-release.list;sudo apt-get update;sudo ACCEPT_EULA=Y apt-get install -y msodbcsql17'
        ]

    # Get the node agent SKU and image reference for the virtual machine
    # configuration.
    # For more information about the virtual machine configuration, see:
    # https://azure.microsoft.com/documentation/articles/batch-linux-nodes/
    sku_to_use, image_ref_to_use = \
        common.helpers.select_latest_verified_vm_image_with_node_agent_sku(
            batch_service_client, publisher, offer, sku)

    new_pool = batch.models.PoolAddParameter(
        id=pool_id,
        virtual_machine_configuration=batchmodels.VirtualMachineConfiguration(
            image_reference=image_ref_to_use,
            node_agent_sku_id=sku_to_use),
        vm_size=_POOL_VM_SIZE,
        target_dedicated=pool_node_count,
        start_task=batch.models.StartTask(
            command_line=common.helpers.wrap_commands_in_shell('linux',
                                                               task_commands),
            #run_elevated=True,
            wait_for_success=True,
            resource_files=resource_files,
            user_identity=batchmodels.UserIdentity(
            auto_user=batchmodels.AutoUserSpecification(
            scope=batchmodels.AutoUserScope.pool,
            elevation_level=batchmodels.ElevationLevel.admin))),
    )

    try:
        batch_service_client.pool.add(new_pool)
    except batchmodels.batch_error.BatchErrorException as err:
        print_batch_exception(err)
        raise


def create_job(batch_service_client, job_id, pool_id):

    print('Creating job [{}]...'.format(job_id))

    job = batch.models.JobAddParameter(
        job_id,
        batch.models.PoolInformation(pool_id=pool_id))

    try:
        batch_service_client.job.add(job)
    except batchmodels.batch_error.BatchErrorException as err:
        print_batch_exception(err)
        raise


def add_tasks(batch_service_client, job_id, input_files, 
              db_server_name, db_name, db_user_name, db_user_pwd, sharedComputeStamp):


    print('Adding {} tasks to job [{}]...'.format(len(input_files), job_id))
    
    user = batchmodels.UserIdentity(
    auto_user=batchmodels.AutoUserSpecification(
        elevation_level=batchmodels.ElevationLevel.admin,
        scope=batchmodels.AutoUserScope.pool))

    tasks = list()

    for idx, input_file in enumerate(input_files):

        command = ['cp $AZ_BATCH_NODE_SHARED_DIR/wd/* $AZ_BATCH_TASK_WORKING_DIR;python $AZ_BATCH_TASK_WORKING_DIR/der_optimization_task.py --inputfilepath {} --db_server_name {} --db_name {} --db_user_name {} --db_user_pwd {} --sharedComputeStamp {}'.format(
                    '$AZ_BATCH_TASK_WORKING_DIR' + '/' + input_file.file_path,
                    db_server_name,
                    db_name,
                    db_user_name,
                    db_user_pwd,
                    sharedComputeStamp)]

        tasks.append(batch.models.TaskAddParameter(
                'topNtask{}'.format(idx),
                common.helpers.wrap_commands_in_shell('linux', command),
                resource_files=[input_file],
                user_identity=user
                )
        )

    batch_service_client.task.add_collection(job_id, tasks)


def wait_for_tasks_to_complete(batch_service_client, job_id, timeout):

    timeout_expiration = datetime.datetime.now() + timeout

    print("Monitoring all tasks for 'Completed' state, timeout in {}...".format(timeout))

    while datetime.datetime.now() < timeout_expiration:
        print('task ongoing...')
        sys.stdout.flush()
        tasks = batch_service_client.task.list(job_id)

        incomplete_tasks = [task for task in tasks if
                            task.state != batchmodels.TaskState.completed]
        if not incomplete_tasks:
            print()
            return True
        else:
            time.sleep(30)

    print()
    raise RuntimeError("ERROR: Tasks did not reach 'Completed' state within "
                       "timeout period of " + str(timeout))


if __name__ == '__main__':

    #Batch and Storage account credential strings
    BATCH_ACCT_NAME = os.environ['BATCH_ACCT_NAME']
    BATCH_KEY = os.environ['BATCH_KEY']
    BATCH_ACCT_URL = os.environ['BATCH_ACCT_URL']

    STORAGE_ACCT = os.environ['STORAGE_ACCT']
    STORAGE_KEY = os.environ['STORAGE_KEY']
    BATCH_APP_CONTAINER = os.environ['BATCH_APP_CONTAINER']
    BATCH_DATA_CONTAINER = os.environ['BATCH_DATA_CONTAINER']
    INCOMING_MSG = os.environ['INCOMING_MSG']
    INCOMING_DATA = os.environ['INCOMING_DATA']

    DB_SVR = os.environ['DB_SVR']
    DB_NAME = os.environ['DB_NAME']
    DB_USR_NAME = os.environ['DB_USR_NAME']
    DB_PWD = os.environ['DB_PWD']

    start_time = datetime.datetime.now().replace(microsecond=0)
    print('Program start: {}'.format(start_time))
    print()
	
    # create the queue client
    print('checking input queue')
    queue_client = azurequeue.QueueService(account_name=STORAGE_ACCT, account_key=STORAGE_KEY)
    messages = queue_client.get_messages(INCOMING_MSG,num_messages=32, visibility_timeout=1)
    if len(messages) == 0:
        print('No incoming optimization request...')
        sys.exit(0)
   
    # Create the blob client
    print('preparing for input storage...')
    blob_client = azureblob.BlockBlobService(
        account_name=STORAGE_ACCT,
        account_key=STORAGE_KEY)

    # preparing input data:
    blobs = blob_client.list_blobs(INCOMING_DATA)
    for blob in blobs:
        blob_url = blob_client.make_blob_url(INCOMING_DATA,blob.name)
        blob_client.copy_blob(BATCH_DATA_CONTAINER, blob.name, blob_url)
        blob_client.delete_blob(INCOMING_DATA,blob.name)	
    for message in messages:
        queue_client.delete_message(INCOMING_MSG, message.id, message.pop_receipt)        

    # Create a Batch service client
    print('creating batch client...')
    credentials = batchauth.SharedKeyCredentials(BATCH_ACCT_NAME,
                                                 BATCH_KEY)

    batch_client = batch.BatchServiceClient(
        credentials,
        base_url=BATCH_ACCT_URL)


    # Paths to the task script. This script will be executed by the tasks that
    # run on the compute nodes.
    print('assembling job scripts...')
    blobs = blob_client.list_blobs(BATCH_APP_CONTAINER)
    application_file_names = [b.name for b in blobs]
    if len(application_file_names)==0:
        print('No optimization task to be performed...')
        sys.exit(0)

    application_files = [
        locate_blob_in_container(blob_client, BATCH_APP_CONTAINER, file)
        for file in application_file_names]

    # prepare the data files. This is the data that will be processed by each of
    # the tasks executed on the compute nodes in the pool.
    print('assembling data files...')
    inputs = blob_client.list_blobs(BATCH_DATA_CONTAINER)
    input_file_names = [input.name for input in inputs]

    input_files = [
        locate_blob_in_container(blob_client, BATCH_DATA_CONTAINER, input)
        for input in input_file_names]

    # Pool parameters
    print('creating pool...')
    _POOL_ID = 'derciqspool' + str(int((start_time-datetime.datetime(1970,1,1)).total_seconds()))
    _POOL_NODE_COUNT = len(input_file_names)
    _JOB_ID = 'derciqsjob' + str(int((start_time-datetime.datetime(1970,1,1)).total_seconds()))


    # Create the pool that will contain the compute nodes that will execute the
    # tasks. The resource files we pass in are used for configuring the pool's
    # start task, which is executed each time a node first joins the pool (or
    # is rebooted or re-imaged).
    create_pool(batch_client,
                _POOL_ID,
                _POOL_NODE_COUNT,
                application_files,
                _NODE_OS_PUBLISHER,
                _NODE_OS_OFFER,
                _NODE_OS_SKU)

    # Create the job that will run the tasks.
    print('creating job...')
    create_job(batch_client, _JOB_ID, _POOL_ID)

    # Add the tasks to the job. 
    print('adding tasks...')
    date_time_base = datetime.datetime(2017,1,1,0,0,0)
    date_time_now = str((datetime.datetime.now()-date_time_base).total_seconds())
    add_tasks(batch_client,
              _JOB_ID,
              input_files,
              DB_SVR,
              DB_NAME,
              DB_USR_NAME,
              DB_PWD,
              date_time_now)


    # Pause execution until tasks reach Completed state.
    print('running task...')
    wait_for_tasks_to_complete(batch_client,
                               _JOB_ID,
                               datetime.timedelta(minutes=60))

    print("All tasks reached the 'Completed' state within the specified timeout period.")


    # Print timing info
    end_time = datetime.datetime.now().replace(microsecond=0)
    print('Program end: {}'.format(end_time))
    print('Elapsed time: {}'.format(end_time - start_time))

    # delete data blobs
    for d in input_file_names:
        blob_client.delete_blob(BATCH_DATA_CONTAINER,d)

    # deleting job
    batch_client.job.delete(_JOB_ID)

	# deleting pool
    batch_client.pool.delete(_POOL_ID)


