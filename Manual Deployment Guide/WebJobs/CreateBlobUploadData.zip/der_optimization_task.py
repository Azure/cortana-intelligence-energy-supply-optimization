import pyomo
import pyomo.opt
import pyomo.environ as pe

import os
import sys
sys.path.insert(0, ".")

from cStringIO import StringIO
import pandas
import itertools
import datetime
import argparse
import pyodbc

def read_csv_multi_table_data(csv_file_name):
    
    desc_table_keys ={}
    desc_table_keys['time_horizon']=set(['TimeInit', 'TimeHorizon'])
    desc_table_keys['time_point']=set(['Interval', 'TimePoint'])
    desc_table_keys['substation_limit']=set(['ImportMaxNum', 'ImportMax', 'ImportMaxPrice', 'SubStationId'])
    desc_table_keys['forecast']=set(['LoadFcst', 'PriceFcst', 'SubStationId', 'TimePoint'])
    desc_table_keys['demand_response']=set(['UpTimeInit', 'DownTimeInit', 'DayUpTimeInit', 'SubStationId', 'DownTimeMin', 'DayUpTimeMax', 'UpTimeMax', 'DRId','UpTimeMin'])
    desc_table_keys['load_reduction']=set(['LoadReductionMax', 'Price', 'LoadReductionMin', 'TimePoint', 'BidId', 'DRId'])
    desc_table_keys['self_scheduled']=set(['GenPrice', 'SubStationId', 'TimePoint', 'SelfScheduledId', 'BidId', 'Gen'])
    desc_table_keys['battery']=set(['BatteryId', 'DischargeRateMin', 'ChargeRateMin', 'SocMin', 'DischargeRateMax', 'SubStationId', 'ChargeRateMax', 'Efficiency', 'GenPrice', 'BidId', 'SocInit', 'LoadPrice', 'SocTerm', 'SocMax'])
    desc_table_keys['dispatchable']=set(['GenPrice', 'GenTerm', 'GenInit', 'GenMin', 'RampDownMax', 'SubStationId', 'GenMax', 'DispatchableId', 'RampUpMax'])

    subfiles = [StringIO()]

    with open(csv_file_name) as bigfile:
        for line in bigfile:
            if ',' not in line:                                                                                                                                       
                subfiles.append(StringIO())
            else: # continuation of same subfile                                                                                                                                                   
                subfiles[-1].write(line.replace(' ',''))

    desc_tables = {}
    
    for sub in subfiles:
        try:
            sub.seek(0)
            table = pandas.read_csv(sub,sep=',')
            for k in desc_table_keys.keys():
                if set(table.keys()).issubset(desc_table_keys[k]):
                    desc_tables[k]=table
                    break
        except:
            continue

    ## clean up substation limit
    df = desc_tables['substation_limit']
    sub_list = sorted(list(set(df['SubStationId'].tolist())))
    if len(sub_list)>1:
        df = df[df['SubStationId']==sub_list[0]]
        df = df.drop_duplicates()
        desc_tables['substation_limit']=df

    ## clean up forecast
    df = desc_tables['forecast']
    sub_list = sorted(list(set(df['SubStationId'].tolist())))
    if len(sub_list)>1:
        df = df[df['SubStationId']==sub_list[0]]
        df = df.drop_duplicates()
        desc_tables['forecast']=df
        
    ## clean up DR
    df = desc_tables['demand_response']
    sub_list = sorted(list(set(df['SubStationId'].tolist())))
    if len(sub_list)>1:
        df = df[df['SubStationId']==sub_list[0]]
        df = df.drop_duplicates()
        desc_tables['demand_response']=df
    if 'UpTimeMin' not in desc_tables['demand_response'].keys():
        uptimemin_list = [0] * desc_tables['demand_response'].shape[0]
        desc_tables['demand_response']['UpTimeMin'] = uptimemin_list

    ## clean up SS
    df = desc_tables['self_scheduled']
    sub_list = sorted(list(set(df['SubStationId'].tolist())))
    if len(sub_list)>1:
        df = df[df['SubStationId']==sub_list[0]]
        df = df.drop_duplicates()
        desc_tables['self_scheduled']=df

    ## clean up Bsttery
    df = desc_tables['battery']
    sub_list = sorted(list(set(df['SubStationId'].tolist())))
    if len(sub_list)>1:
        df = df[df['SubStationId']==sub_list[0]]
        df = df.drop_duplicates()
        desc_tables['battery']=df

    ## clean up dispatchable
    df = desc_tables['dispatchable']
    sub_list = sorted(list(set(df['SubStationId'].tolist())))
    if len(sub_list)>1:
        df = df[df['SubStationId']==sub_list[0]]
        df = df.drop_duplicates()
        desc_tables['dispatchable']=df

    return desc_tables

def read_csv_multi_table_config(csv_file_name):
    
    desc_table_keys ={}
    desc_table_keys['opt_model']=set(['Objective', 'Goal','SlackCost'])
    desc_table_keys['resource_list']=set(['IsIncluded', 'Resource'])
    desc_table_keys['constraint_list']=set(['IsIncluded', 'Resource', 'Constraint'])
    desc_table_keys['solver_spec']=set(['CLParPath', 'Solver', 'CLExePath', 'IsToWriteCMSFile', 'Separator', 'Interface', 'IsToWriteLPFile', 'CMS','IsToOutputViolations', 'IsToOutputBidId'])
    subfiles = [StringIO()]

    with open(csv_file_name) as bigfile:
        for line in bigfile:
            if ',' not in line:                                                                                                                                       
                subfiles.append(StringIO())
            else: # continuation of same subfile                                                                                                                                                   
                subfiles[-1].write(line.replace(' ',''))

    desc_tables = {}
    
    for sub in subfiles:
        try:
            sub.seek(0)
            table = pandas.read_csv(sub,sep=',')
            for k in desc_table_keys.keys():
                if set(table.keys())== desc_table_keys[k]:
                    desc_tables[k]=table
                    break
        except:
            continue

    return desc_tables


def DEROPTMODEL(desc_tables):
    
    TimeStamp_list = sorted(set(desc_tables['time_point']['TimePoint'].tolist()))
    desc_tables['time_point'].set_index(['TimePoint'], inplace=True)
    time_unit={}
    for t in TimeStamp_list:
        time_unit[t] = float(desc_tables['time_point'].ix[t,'Interval'])/60.0

    ######## create model ########
    dermodel = pe.ConcreteModel()
    desc_tables['resource_list'].set_index(['Resource'], inplace=True)
    desc_tables['constraint_list'].set_index(['Resource','Constraint'], inplace=True)
    substation_obj_cost_str = '0'
    substation_obj_vio_cost_str = '0'
    battery_pos_obj_str = '0'
    battery_neg_obj_str = '0'
    battery_obj_vio_str = '0'
    dr_obj_str = '0'
    dr_obj_vio_str = '0'
    ss_obj_str = '0'
    dis_obj_str = '0'
    dis_obj_vio_str = '0'
   

    ######## substation model ########
    SubStation_list=sorted(set(desc_tables['substation_limit']['SubStationId'].tolist()))

    if desc_tables['resource_list'].ix['SubStation','IsIncluded']=='Yes' and len(SubStation_list)>0:
        
        # declare sets
        SubStation_varkeylist = list(itertools.product(SubStation_list,TimeStamp_list))
        dermodel.substation_set =pe.Set(initialize=SubStation_varkeylist)
        
        SubStation_Violation_varkeylist = []
        for s in SubStation_list:
            violation_sub = desc_tables['substation_limit'][desc_tables['substation_limit']['SubStationId']==s]
            violation_sub_list = violation_sub['ImportMaxNum'].tolist()
            SubStation_Violation_varkeylist = SubStation_Violation_varkeylist + list(itertools.product([s],violation_sub_list,TimeStamp_list))
        dermodel.substation_violation_set =pe.Set(initialize=SubStation_Violation_varkeylist)

        # declare variables
        dermodel.substation_load = pe.Var(dermodel.substation_set, domain=pe.NonNegativeReals)
        dermodel.substation_sale = pe.Var(dermodel.substation_set, domain=pe.NonNegativeReals)
        dermodel.import_commit = pe.Var(dermodel.substation_set, domain=pe.Binary)
        dermodel.export_commit = pe.Var(dermodel.substation_set, domain=pe.Binary)
        dermodel.substation_violation = pe.Var(dermodel.substation_violation_set, domain=pe.NonNegativeReals)

        # declare objectives
        desc_tables['forecast'].set_index(['SubStationId', 'TimePoint'], inplace=True)
        substation_obj_cost_str = 'sum([dermodel.substation_load[x]*desc_tables[\'forecast\'].ix[x,\'PriceFcst\']*time_unit[x[1]] for x in SubStation_varkeylist])'
        substation_obj_revenue_str = 'sum([dermodel.substation_sale[x]*desc_tables[\'forecast\'].ix[x,\'PriceFcst\']*time_unit[x[1]] for x in SubStation_varkeylist])'
        
        desc_tables['substation_limit'].set_index(['SubStationId', 'ImportMaxNum'], inplace=True)
        price_cost = {}
        for x in SubStation_Violation_varkeylist:
            price_cost[x] = time_unit[x[2]]*desc_tables['substation_limit'].ix[(x[0],x[1]),'ImportMaxPrice']            
        substation_obj_vio_cost_str = 'sum([dermodel.substation_violation[x]*price_cost[x] for x in SubStation_Violation_varkeylist])'

            
        # declare constraints
        # 1. power limits
        for x in SubStation_varkeylist:
            for y in SubStation_Violation_varkeylist:
                if x[0] == y[0] and x[1] == y[2]:
                    substation_violation_const_str = 'dermodel.substation_load[x]<=desc_tables[\'substation_limit\'].ix[(y[0],y[1]),\'ImportMax\']+dermodel.substation_violation[y]'
                    const_str = 'dermodel.sub_violation_const_'+str(y[0])+'_'+str(y[1])+'_'+str(x[1])+'=pe.Constraint(expr='+substation_violation_const_str +')'
                    exec(const_str)
                    sale_violation_const_str = 'dermodel.substation_sale[x]<=desc_tables[\'substation_limit\'].ix[(y[0],y[1]),\'ImportMax\']+dermodel.substation_violation[y]'
                    const_str = 'dermodel.sale_violation_const_'+str(y[0])+'_'+str(y[1])+'_'+str(x[1])+'=pe.Constraint(expr='+sale_violation_const_str +')'
                    exec(const_str)        

        # 2. no import and export at the same time
        for x in SubStation_varkeylist:
            import_export_str = 'dermodel.import_commit[x]+dermodel.export_commit[x]<=1'
            const_str = 'dermodel.sub_im_ex_const_'+str(x[0])+'_'+str(x[1])+'=pe.Constraint(expr='+import_export_str+')'
            exec(const_str)

        # 3. Absolute upper 
        desc_tables['substation_limit']=desc_tables['substation_limit'].reset_index()
        for s in SubStation_list:
            upper_sub = desc_tables['substation_limit'][desc_tables['substation_limit']['SubStationId']==s]
            upper = max(upper_sub['ImportMax'].tolist())
            for x in SubStation_varkeylist:
                if x[0]==s:
                    absolute_upper_str = 'dermodel.substation_load[x]<=upper*dermodel.import_commit[x]'
                    const_str = 'dermodel.sub_absoluteload_const_'+str(x[0])+'_'+str(x[1])+'=pe.Constraint(expr='+absolute_upper_str+')'
                    exec(const_str)
                    absolute_upper_str = 'dermodel.substation_sale[x]<=upper*dermodel.export_commit[x]'
                    const_str = 'dermodel.sub_absolutesale_const_'+str(x[0])+'_'+str(x[1])+'=pe.Constraint(expr='+absolute_upper_str+')'
                    exec(const_str)
                    
    ######## self_scheduled model ########
    SelfScheduled_list=sorted(set(desc_tables['self_scheduled']['SelfScheduledId'].tolist()))

    if desc_tables['resource_list'].ix['SelfScheduled','IsIncluded']=='Yes' and len(SelfScheduled_list)>0:
        
        # declare sets
        SelfScheduled_varkeylist = list(itertools.product(SelfScheduled_list,TimeStamp_list))       
        dermodel.selfscheduled_set =pe.Set(initialize=SelfScheduled_varkeylist)

        # declare variables
        dermodel.self_scheduled = pe.Var(dermodel.selfscheduled_set, domain=pe.NonNegativeReals)
        
        # declare objectives
        desc_tables['self_scheduled'].set_index(['SelfScheduledId', 'TimePoint'], inplace=True)
        ss_obj_str = 'sum([dermodel.self_scheduled[x]*desc_tables[\'self_scheduled\'].ix[x,\'GenPrice\']*time_unit[x[1]] for x in SelfScheduled_varkeylist])'

        # describe constraints
        for x in SelfScheduled_varkeylist:
            ss_const_str = 'dermodel.ss_const_'+str(x[0])+'_'+str(x[1])+'=pe.Constraint(expr=dermodel.self_scheduled[x]==desc_tables[\'self_scheduled\'].ix[x,\'Gen\'])'
            exec(ss_const_str)

    ######## dispatchable model ########
    Dispatchable_list=sorted(set(desc_tables['dispatchable']['DispatchableId'].tolist()))

    if desc_tables['resource_list'].ix['Dispatchable','IsIncluded']=='Yes' and len(Dispatchable_list)>0:
        Dispatchable_varkeylist = list(itertools.product(Dispatchable_list,TimeStamp_list))
        dermodel.dispatchable_set =pe.Set(initialize=Dispatchable_varkeylist)

        # declare variables
        dermodel.dispatchable = pe.Var(dermodel.dispatchable_set, domain=pe.NonNegativeReals)
        dermodel.dispatchable_commit = pe.Var(dermodel.dispatchable_set, domain=pe.Binary)
        dermodel.dispatchable_startup = pe.Var(dermodel.dispatchable_set, domain=pe.Binary)
        dermodel.dispatchable_shutdown = pe.Var(dermodel.dispatchable_set, domain=pe.Binary)
            
        # declare objective 
        desc_tables['dispatchable'].set_index(['DispatchableId'], inplace=True)
        dis_obj_str = 'sum([dermodel.dispatchable[x]*desc_tables[\'dispatchable\'].ix[x[0],\'GenPrice\']*time_unit[x[1]] for x in Dispatchable_varkeylist])'
        dis_obj_vio_str = '0' # !!!! 
        
        # describe constraints
        # 1. no startup and shutdown at the same time
        for x in Dispatchable_varkeylist:
            dis_start_shut_sametime_const_str = 'dermodel.dis_start_shut_same_'+str(x[0])+'_'+str(x[1])+'=pe.Constraint(expr=dermodel.dispatchable_startup[x] + dermodel.dispatchable_shutdown[x] <=1)'
            exec(dis_start_shut_sametime_const_str)

        # 2. Startup and shutdown 
        for d in Dispatchable_list:
            for t in range(1,len(TimeStamp_list)):
                first_key = (d,TimeStamp_list[t-1])
                second_key = (d,TimeStamp_list[t])
                dis_start_shut_const_str = 'dermodel.dis_start_shut_'+str(d) + '_' + str(t)+'=pe.Constraint(expr=dermodel.dispatchable_startup[second_key]- dermodel.dispatchable_shutdown[second_key] == dermodel.dispatchable_commit[second_key]-dermodel.dispatchable_commit[first_key])'
                exec(dis_start_shut_const_str)

        # 3. init and term conditions
        for b in Dispatchable_list:
            if desc_tables['constraint_list'].ix[('Dispatchable','InitialCondition'),'IsIncluded']=='Yes':
                initkey = (b,TimeStamp_list[0])
                dis_init_const_str = 'dermodel.dis_init_'+str(b)+'=pe.Constraint(expr=dermodel.dispatchable_commit[initkey] == (1 if desc_tables[\'dispatchable\'].ix[initkey[0],\'GenInit\']>0 else 0))'
                exec(dis_init_const_str)
            #### no terminal condition

        # 4. Ramping up dynamic
        for d in Dispatchable_list:
            for t in range(1,len(TimeStamp_list)):
                first_key = (d,TimeStamp_list[t-1])
                second_key = (d,TimeStamp_list[t])
                ramp_up_str ='dermodel.dispatchable[second_key]-dermodel.dispatchable[first_key]<=(1-dermodel.dispatchable_startup[second_key])*desc_tables[\'dispatchable\'].ix[second_key[0],\'RampUpMax\']*time_unit[first_key[1]]+desc_tables[\'dispatchable\'].ix[second_key[0],\'GenMin\']*dermodel.dispatchable_startup[second_key]'
                ramp_up_const_str = 'dermodel.dis_ramp_up_'+str(d) + '_' + str(t)+'=pe.Constraint(expr=' +ramp_up_str+ ')'
                exec(ramp_up_const_str)

        # 5. Ramping down dynamic
        for d in Dispatchable_list:
            for t in range(1,len(TimeStamp_list)):
                first_key = (d,TimeStamp_list[t-1])
                second_key = (d,TimeStamp_list[t])
                ramp_down_str ='dermodel.dispatchable[second_key]-dermodel.dispatchable[first_key]>=-(1-dermodel.dispatchable_shutdown[second_key])*desc_tables[\'dispatchable\'].ix[second_key[0],\'RampDownMax\']*time_unit[first_key[1]]+desc_tables[\'dispatchable\'].ix[second_key[0],\'GenMax\']*dermodel.dispatchable_shutdown[second_key]'
                ramp_down_const_str = 'dermodel.dis_ramp_down_'+str(d) + '_' + str(t)+'=pe.Constraint(expr=' +ramp_down_str+ ')'
                exec(ramp_down_const_str)

    ######## Battery Model  ########
    Battery_list=sorted(set(desc_tables['battery']['BatteryId'].tolist()))

    if desc_tables['resource_list'].ix['Battery','IsIncluded']=='Yes' and len(Battery_list)>0:
        Battery_varkeylist = list(itertools.product(Battery_list,TimeStamp_list))       
        dermodel.battery_set =pe.Set(initialize=Battery_varkeylist)

        # declare variables
        dermodel.battery_gen = pe.Var(dermodel.battery_set, domain=pe.NonNegativeReals)
        dermodel.battery_charge = pe.Var(dermodel.battery_set, domain=pe.NonNegativeReals)
        dermodel.battery_soc = pe.Var(dermodel.battery_set, domain=pe.NonNegativeReals)
        dermodel.battery_gencommit = pe.Var(dermodel.battery_set, domain=pe.Binary)
        dermodel.battery_chargecommit = pe.Var(dermodel.battery_set, domain=pe.Binary)
        dermodel.battery_socdeficit = pe.Var(dermodel.battery_set, domain=pe.NonNegativeReals)
        dermodel.battery_socexcess = pe.Var(dermodel.battery_set, domain=pe.NonNegativeReals)

        # decalre objectives
        desc_tables['battery'].set_index(['BatteryId'], inplace=True)
        battery_pos_obj_str = 'sum([dermodel.battery_gen[x]*desc_tables[\'battery\'].ix[x[0],\'GenPrice\']*time_unit[x[1]] for x in Battery_varkeylist])'
        battery_neg_obj_str = 'sum([dermodel.battery_charge[x]*desc_tables[\'battery\'].ix[x[0],\'LoadPrice\']*time_unit[x[1]] for x in Battery_varkeylist])'
        battery_obj_vio_str = '0' # !!!!!!!! violation price

        # describe constraints
        # 1. state of charge constraints
        for x in Battery_varkeylist:
            bat_soc_const_low_str = 'dermodel.bat_socmin_'+str(x[0])+'_'+str(x[1])+'=pe.Constraint(expr=dermodel.battery_soc[x]+dermodel.battery_socdeficit[x]-dermodel.battery_socexcess[x] >= desc_tables[\'battery\'].ix[x[0],\'SocMin\'])'
            exec(bat_soc_const_low_str)
            bat_soc_const_high_str = 'dermodel.bat_socmax_'+str(x[0])+'_'+str(x[1])+'=pe.Constraint(expr=dermodel.battery_soc[x]+dermodel.battery_socdeficit[x]-dermodel.battery_socexcess[x] <= desc_tables[\'battery\'].ix[x[0],\'SocMax\'])'
            exec(bat_soc_const_high_str)
        
        # 2. no charge and discharge(gen) at the same time
        for x in Battery_varkeylist:
            charge_gen_const_str = 'dermodel.bat_charge_gen_'+str(x[0])+'_'+str(x[1])+'=pe.Constraint(expr=dermodel.battery_chargecommit[x] + dermodel.battery_gencommit[x] <=1)'
            exec(charge_gen_const_str)
            
        # 3. generation limits
        for x in Battery_varkeylist:
            gen_limit_const_str = 'dermodel.bat_gen_limit_low_'+str(x[0])+'_'+str(x[1])+'=pe.Constraint(expr=dermodel.battery_gen[x] >= desc_tables[\'battery\'].ix[x[0],\'DischargeRateMin\']*dermodel.battery_gencommit[x])'
            exec(gen_limit_const_str)
            gen_limit_const_str = 'dermodel.bat_gen_limit_high_'+str(x[0])+'_'+str(x[1])+'=pe.Constraint(expr=dermodel.battery_gen[x] <= desc_tables[\'battery\'].ix[x[0],\'DischargeRateMax\']*dermodel.battery_gencommit[x])'
            exec(gen_limit_const_str)
            
        # 4. charge limits
        for x in Battery_varkeylist:
            charge_limit_const_str = 'dermodel.bat_charge_limit_low_'+str(x[0])+'_'+str(x[1])+'=pe.Constraint(expr=dermodel.battery_charge[x] >= desc_tables[\'battery\'].ix[x[0],\'ChargeRateMin\']*dermodel.battery_chargecommit[x])'
            exec(charge_limit_const_str)
            charge_limit_const_str = 'dermodel.bat_charge_limit_high_'+str(x[0])+'_'+str(x[1])+'=pe.Constraint(expr=dermodel.battery_charge[x] <= desc_tables[\'battery\'].ix[x[0],\'ChargeRateMax\']*dermodel.battery_chargecommit[x])'
            exec(charge_limit_const_str)
        
        # 5. Battery init and term conditions
        #desc_tables['constraint_list'].set_index(['Resource','Constraint'], inplace=True)        
        for b in Battery_list:
            if desc_tables['constraint_list'].ix[('Battery','InitialCondition'),'IsIncluded']=='Yes':
                initkey = (b,TimeStamp_list[0])
                bat_init_const_str = 'dermodel.bat_init_'+str(b)+'=pe.Constraint(expr=dermodel.battery_soc[initkey] == desc_tables[\'battery\'].ix[initkey[0],\'SocInit\'])'
                exec(bat_init_const_str)
            if desc_tables['constraint_list'].ix[('Battery','TerminalCondition'),'IsIncluded']=='Yes':
                termkey = (b,TimeStamp_list[-1])
                bat_term_const_str = 'dermodel.bat_term_'+str(b)+'=pe.Constraint(expr=dermodel.battery_soc[termkey] == desc_tables[\'battery\'].ix[termkey[0],\'SocTerm\'])'
                exec(bat_term_const_str)
        
        # 6. dynamic retriction
        for b in Battery_list:
            for t in range(1,len(TimeStamp_list)):
                first_key = (b,TimeStamp_list[t-1])
                second_key = (b,TimeStamp_list[t])
                bat_dynamic_const_str = 'dermodel.bat_dynamic_'+str(b) + '_' + str(t)+'=pe.Constraint(expr=dermodel.battery_soc[second_key] == dermodel.battery_soc[first_key]+(dermodel.battery_charge[second_key]*desc_tables[\'battery\'].ix[second_key[0],\'Efficiency\']-dermodel.battery_gen[second_key])*time_unit[x[1]])'
                exec(bat_dynamic_const_str)
            
    ######## demand response model ########
    DemandResponse_list=sorted(set(desc_tables['demand_response']['DRId'].tolist()))
        
    if desc_tables['resource_list'].ix['DemandResponse','IsIncluded']=='Yes' and len(DemandResponse_list)>0:
        DemandResponse_varkeylist = list(itertools.product(DemandResponse_list,TimeStamp_list))       
        dermodel.demandresponse_set =pe.Set(initialize=DemandResponse_varkeylist)

        # declare variables
        dermodel.load_reduction = pe.Var(dermodel.demandresponse_set, domain=pe.NonNegativeReals)
        dermodel.load_reductioncommit = pe.Var(dermodel.demandresponse_set, domain=pe.Binary)
        dermodel.startup = pe.Var(dermodel.demandresponse_set, domain=pe.Binary)
        dermodel.shutdown = pe.Var(dermodel.demandresponse_set, domain=pe.Binary)
        dermodel.uptime_excess = pe.Var(dermodel.demandresponse_set, domain=pe.NonNegativeReals)
        dermodel.uptime_deficit = pe.Var(dermodel.demandresponse_set, domain=pe.NonNegativeReals)
        dermodel.dayuptime_excess = pe.Var(dermodel.demandresponse_set, domain=pe.NonNegativeReals)
        dermodel.downtime_deficit = pe.Var(dermodel.demandresponse_set, domain=pe.NonNegativeReals)

        # declare objective
        desc_tables['demand_response'].set_index(['DRId'], inplace=True)
        desc_tables['load_reduction'].set_index(['DRId','TimePoint'], inplace=True)
        dr_obj_str = 'sum([dermodel.load_reduction[x]*desc_tables[\'load_reduction\'].ix[x,\'Price\']*time_unit[x[1]] for x in DemandResponse_varkeylist])'
        dr_obj_vio_str = '0'# !!!! violation

        # declare constraint
        # 1. load reduction bound constraint
        for x in DemandResponse_varkeylist:
            dr_limit_const_str = 'dermodel.dr_gen_limit_low_'+str(x[0])+'_'+str(x[1])+'=pe.Constraint(expr=dermodel.load_reduction[x] >= desc_tables[\'load_reduction\'].ix[x,\'LoadReductionMin\']*dermodel.load_reductioncommit[x])'
            exec(dr_limit_const_str)
            dr_limit_const_str = 'dermodel.dr_gen_limit_high_'+str(x[0])+'_'+str(x[1])+'=pe.Constraint(expr=dermodel.load_reduction[x] <= desc_tables[\'load_reduction\'].ix[x,\'LoadReductionMax\']*dermodel.load_reductioncommit[x])'
            exec(dr_limit_const_str)

        # 2. no startup and shutdown at the same time
        for x in DemandResponse_varkeylist:
            dr_start_shut_sametime_const_str = 'dermodel.dr_start_shut_same_'+str(x[0])+'_'+str(x[1])+'=pe.Constraint(expr=dermodel.startup[x] + dermodel.shutdown[x] <=1)'
            exec(dr_start_shut_sametime_const_str)
        
        # 3. Startup and shutdown 
        for d in DemandResponse_list:
            for t in range(1,len(TimeStamp_list)):
                first_key = (d,TimeStamp_list[t-1])
                second_key = (d,TimeStamp_list[t])
                dr_start_shut_const_str = 'dermodel.dr_start_shut_'+str(d) + '_' + str(t)+'=pe.Constraint(expr=dermodel.startup[second_key]- dermodel.shutdown[second_key] == dermodel.load_reductioncommit[second_key]-dermodel.load_reductioncommit[first_key])'
                exec(dr_start_shut_const_str)
        
        # prepare for accumulated time
        accum={}
        accum[0]=0.0
        for x in TimeStamp_list:
            accum[x] = accum[x-1]+float(desc_tables['time_point'].ix[x,'Interval'])/60

        # 4. max up time
        for d in DemandResponse_list:
            uptimemax = desc_tables['demand_response'].ix[d,'UpTimeMax']
            for t in range(1,len(TimeStamp_list)+1):
                tstart = -1
                for delta in range(t):
                    tstart=t-delta
                    if accum[t]-accum[tstart-1] >=uptimemax:
                        break
                if tstart >= 1:
                    max_up_time_str = 'dermodel.dr_up_max_'+str(d) + '_' + str(t)+'=pe.Constraint(expr=sum([dermodel.load_reductioncommit[(d,x)]*desc_tables[\'time_point\'].ix[x,\'Interval\'] for x in range(tstart,t+1)])-dermodel.uptime_excess[(d,t)]<=uptimemax)'
                    exec(max_up_time_str)

        # 5. minimum up time
        for d in DemandResponse_list:
            uptimemin = desc_tables['demand_response'].ix[d,'UpTimeMin']
            for t in range(1,len(TimeStamp_list)+1):
                tstart = -1
                for delta in range(t):
                    tstart=t-delta
                    if accum[t]-accum[tstart-1] >=uptimemin:
                        break
                if tstart >= 1:
                    min_up_time_str = 'dermodel.dr_up_min_'+str(d) + '_' + str(t)+'=pe.Constraint(expr=sum([dermodel.load_reductioncommit[(d,x)]*desc_tables[\'time_point\'].ix[x,\'Interval\'] for x in range(tstart,t+1)])+dermodel.uptime_deficit[(d,t)]>=uptimemin)'
                    exec(min_up_time_str)
        
        # 6. maximum day up time
        for d in DemandResponse_list:
            dayuptimemax = desc_tables['demand_response'].ix[d,'DayUpTimeMax']
            for t in range(1,len(TimeStamp_list)+1):
                tstart = -1
                for delta in range(t):
                    tstart=t-delta
                    if accum[t]-accum[tstart-1] >=dayuptimemax:
                        break
                if tstart >= 1:
                    max_day_up_time_str = 'dermodel.dr_day_up_max_'+str(d) + '_' + str(t)+'=pe.Constraint(expr=sum([dermodel.load_reductioncommit[(d,x)]*desc_tables[\'time_point\'].ix[x,\'Interval\'] for x in range(tstart,t+1)])-dermodel.dayuptime_excess[(d,t)]<=dayuptimemax)'
                    exec(max_day_up_time_str)
        
        # 7. minimum down time
        for d in DemandResponse_list:
            downtimemin = desc_tables['demand_response'].ix[d,'DownTimeMin']
            for t in range(1,len(TimeStamp_list)+1):
                tstart = -1
                for delta in range(t):
                    tstart=t-delta
                    if accum[t]-accum[tstart-1] >=downtimemin:
                        break
                if tstart >= 1:
                    down_time_min_str = 'dermodel.dr_down_time_min_'+str(d) + '_' + str(t)+'=pe.Constraint(expr=sum([dermodel.startup[(d,x)] for x in range(tstart,t+1)])-dermodel.downtime_deficit[(d,x)]<=1-dermodel.load_reductioncommit[(d,t)])'
                    exec(down_time_min_str)

    #### power balance constraints ####
    for t in TimeStamp_list:
        substation_load_str = 'sum([dermodel.substation_load[(x,t)] for x in SubStation_list])'
        battery_load_str = 'sum([dermodel.battery_gen[(x,t)] for x in Battery_list])'        
        ss_load_str = 'sum([dermodel.self_scheduled[(x,t)] for x in SelfScheduled_list])'
        dis_load_str = 'sum([dermodel.dispatchable[(x,t)] for x in Dispatchable_list])'
        forecast_str = 'sum([desc_tables[\'forecast\'].ix[(x,t),\'LoadFcst\'] for x in SubStation_list])'
        substation_sale_str = 'sum([dermodel.substation_sale[(x,t)] for x in SubStation_list])'
        battery_charge_str = 'sum([dermodel.battery_charge[(x,t)] for x in Battery_list])'        
        DR_str = 'sum([dermodel.load_reduction[(x,t)] for x in DemandResponse_list])' 
        sum_str = substation_load_str+'+'+battery_load_str+'+'+ss_load_str+'+'+dis_load_str+'=='+forecast_str+'+'+substation_sale_str+'+'+battery_charge_str+'-'+DR_str
        const_str = 'dermodel.balance_const_'+str(t) +'=pe.Constraint(expr='+sum_str+')'
        exec(const_str)

    #### declare Objective ####
    Obj = desc_tables['opt_model']['Objective'].tolist()[0]
    if Obj == 'Cost':
        obj_str = 'dermodel.obj=pe.Objective(expr=' + substation_obj_vio_cost_str + '+' + substation_obj_cost_str + '+' + battery_pos_obj_str + '-' + battery_neg_obj_str + '+' + battery_obj_vio_str + '+' + dr_obj_str + '+' + dr_obj_vio_str + '+' + ss_obj_str + '+' + dis_obj_str + '+' + dis_obj_vio_str + ')'
        exec(obj_str)
  
        
    
    #### specify solver
    solver_name = desc_tables['solver_spec']['Solver'].tolist()[0]
    solver_path = desc_tables['solver_spec']['CLExePath'].tolist()[0]
    solver = pyomo.opt.SolverFactory(solver_name,executable=solver_path)
    
    #### run    
    Goal = desc_tables['opt_model']['Goal'].tolist()[0]
    if Goal =='Minimize':
        results = solver.solve(dermodel)
        results.write()
    
    print "computation complete!"
    
    objval = float(dermodel.obj())
    id_list = []
    timestamp_list=[]
    quantity_name_list = []
    quantity_val_list = []
    objval_list = []
    base_cost = []
    computeStamp_list =[]
    
    # compute red objective
    max_load_cost = 0
    for k in sorted(dermodel.substation_load):
        max_df = desc_tables['substation_limit'][desc_tables['substation_limit']['SubStationId']==k[0]]
        max_import = min(max_df['ImportMax'].tolist())
        if dermodel.substation_load[k].value < max_import:
            max_load_cost += (max_import-dermodel.substation_load[k].value)*desc_tables['forecast'].ix[k,'PriceFcst']*time_unit[k[1]]
    max_load_cost +=objval
    
    result_df = pandas.DataFrame(columns=['ID','Time Stamp','Quantity','Value','ObjValue','BaseValue','computeStamp'])
    date_time_base = datetime.datetime(2017,1,1,0,0,0)
    date_time_now = (datetime.datetime.now()-date_time_base).total_seconds()

    if desc_tables['resource_list'].ix['SubStation','IsIncluded']=='Yes' and len(SubStation_list)>0:
        for k in sorted(dermodel.substation_load):
            id_list.append(k[0]) 
            timestamp_list.append(k[1])
            quantity_name_list.append('load')
            quantity_val_list.append(float(dermodel.substation_load[k].value))
            objval_list.append(objval)
            computeStamp_list.append(date_time_now)
            base_cost.append(max_load_cost)
        for k in sorted(dermodel.substation_sale):
            id_list.append(k[0]) 
            timestamp_list.append(k[1])
            quantity_name_list.append('sale')
            quantity_val_list.append(float(dermodel.substation_sale[k].value))
            objval_list.append(objval)
            computeStamp_list.append(date_time_now)
            base_cost.append(max_load_cost)
    
    if desc_tables['resource_list'].ix['Battery','IsIncluded']=='Yes' and len(Battery_list)>0:
        for k in sorted(dermodel.battery_gen):
            id_list.append(k[0]) 
            timestamp_list.append(k[1])
            quantity_name_list.append('discharge')
            quantity_val_list.append(float(dermodel.battery_gen[k].value*dermodel.battery_gencommit[k].value))
            objval_list.append(objval)
            computeStamp_list.append(date_time_now)
            base_cost.append(max_load_cost)
        
        for k in sorted(dermodel.battery_charge):
            id_list.append(k[0]) 
            timestamp_list.append(k[1])
            quantity_name_list.append('charge')
            quantity_val_list.append(float(dermodel.battery_charge[k].value*dermodel.battery_chargecommit[k].value))
            objval_list.append(objval)
            computeStamp_list.append(date_time_now)
            base_cost.append(max_load_cost)
   
    if desc_tables['resource_list'].ix['DemandResponse','IsIncluded']=='Yes' and len(DemandResponse_list)>0:        
        for k in sorted(dermodel.load_reduction):
            id_list.append(k[0]) 
            timestamp_list.append(k[1])
            quantity_name_list.append('load reduction')
            quantity_val_list.append(float(dermodel.load_reduction[k].value*dermodel.load_reductioncommit[k].value))
            objval_list.append(objval)
            computeStamp_list.append(date_time_now)
            base_cost.append(max_load_cost)
    
    if desc_tables['resource_list'].ix['Dispatchable','IsIncluded']=='Yes' and len(Dispatchable_list)>0:
        for k in sorted(dermodel.dispatchable):
            id_list.append(k[0]) 
            timestamp_list.append(k[1])
            quantity_name_list.append('generation')
            quantity_val_list.append(float(dermodel.dispatchable[k].value*dermodel.dispatchable_commit[k].value))
            objval_list.append(objval)
            computeStamp_list.append(date_time_now)
            base_cost.append(max_load_cost)

    result_df['ID']=id_list
    result_df['Time Stamp']=timestamp_list
    result_df['Quantity']=quantity_name_list
    result_df['Value']=quantity_val_list
    result_df['ObjValue']=objval_list
    result_df['computeStamp']=computeStamp_list
    result_df['BaseValue']=base_cost
    
    return result_df

def aggregate_input(desc_tables):
    agg_dict ={}
    agg_dict['ID'] = []
    agg_dict['Time Stamp'] = []
    agg_dict['Quantity'] = []
    agg_dict['Value'] = []
    agg_dict['computeStamp'] = []

    date_time_base = datetime.datetime(2017,1,1,0,0,0)
    date_time_now = (datetime.datetime.now()-date_time_base).total_seconds()

    # subtation
    rows = desc_tables['time_point'].shape[0]
    agg_dict['ID'].extend(desc_tables['forecast']['SubStationId'].tolist())
    agg_dict['Time Stamp'].extend(desc_tables['forecast']['TimePoint'].tolist())
    agg_dict['Quantity'].extend(['PriceForecast']*rows)
    agg_dict['Value'].extend(desc_tables['forecast']['PriceFcst'].tolist())
    agg_dict['computeStamp'].extend([date_time_now]*rows)
    agg_dict['ID'].extend(desc_tables['forecast']['SubStationId'].tolist())
    agg_dict['Time Stamp'].extend(desc_tables['forecast']['TimePoint'].tolist())
    agg_dict['Quantity'].extend(['LoadForecast']*rows)
    agg_dict['Value'].extend(desc_tables['forecast']['LoadFcst'].tolist())
    agg_dict['computeStamp'].extend([date_time_now]*rows)
    
    #DR
    unique_ID = set(desc_tables['load_reduction']['DRId'].tolist())
    for x in unique_ID:
        agg_dict['ID'].append(x)
        agg_dict['Time Stamp'].append(-1)
        agg_dict['Quantity'].append('DR Price')
        agg_dict['Value'].append(desc_tables['load_reduction']['Price'].tolist()[0])
        agg_dict['computeStamp'].append(date_time_now)        
    
    ##SS
    unique_ID = set(desc_tables['self_scheduled']['SelfScheduledId'].tolist())
    for x in unique_ID:
        agg_dict['ID'].append(x)
        agg_dict['Time Stamp'].append(-1)
        agg_dict['Quantity'].append('SS Price')
        agg_dict['Value'].append(desc_tables['self_scheduled']['GenPrice'].tolist()[0])
        agg_dict['computeStamp'].append(date_time_now) 
        agg_dict['ID'].append(x)
        agg_dict['Time Stamp'].append(-1)
        agg_dict['Quantity'].append('SS Generation')
        agg_dict['Value'].append(desc_tables['self_scheduled']['Gen'].tolist()[0])
        agg_dict['computeStamp'].append(date_time_now) 

    ## Battery
    unique_ID = set(desc_tables['battery']['BatteryId'].tolist())
    for x in unique_ID:
        agg_dict['ID'].append(x)
        agg_dict['Time Stamp'].append(-1)
        agg_dict['Quantity'].append('Battery Gen Price')
        agg_dict['Value'].append(desc_tables['battery']['GenPrice'].tolist()[0])
        agg_dict['computeStamp'].append(date_time_now) 
        agg_dict['ID'].append(x)
        agg_dict['Time Stamp'].append(-1)
        agg_dict['Quantity'].append('Battery Charge Price')
        agg_dict['Value'].append(desc_tables['battery']['LoadPrice'].tolist()[0])
        agg_dict['computeStamp'].append(date_time_now)

    ## Battery
    unique_ID = set(desc_tables['dispatchable']['DispatchableId'].tolist())
    for x in unique_ID:
        agg_dict['ID'].append(x)
        agg_dict['Time Stamp'].append(-1)
        agg_dict['Quantity'].append('Dispatchable Price')
        agg_dict['Value'].append(desc_tables['dispatchable']['GenPrice'].tolist()[0])
        agg_dict['computeStamp'].append(date_time_now) 
        
    return agg_dict
	
if __name__ == '__main__':

    print 'parsing task arguments...'
    parser = argparse.ArgumentParser()
    #parser.add_argument('--inputstorageaccount', required=True)
    parser.add_argument('--inputfilepath', required=True)
    parser.add_argument('--db_server_name', required=True)
    parser.add_argument('--db_name', required=True)
    parser.add_argument('--db_user_name', required=True)
    parser.add_argument('--db_user_pwd', required=True)
    parser.add_argument('--sharedComputeStamp', required=True)    
    args = parser.parse_args()

    input_file = os.path.realpath(args.inputfilepath)
    db_server_name = args.db_server_name
    db_name = args.db_name
    db_user_name = args.db_user_name
    db_user_pwd = args.db_user_pwd
    sharedComputeStamp = float(args.sharedComputeStamp)
 
    data_tables = read_csv_multi_table_data(input_file)
    config_tables = read_csv_multi_table_config('modelConfig.txt')
    desc_tables = data_tables
    desc_tables.update(config_tables)
	
    agg_dict = aggregate_input(desc_tables)
    No_input_rows = len(agg_dict['ID'])

    print 'performing optimization...'	
    result_df = DEROPTMODEL(desc_tables)

    print 'assemble optimization results...'
    id_list =result_df['ID'].tolist()
    timestamp_list = result_df['Time Stamp'].tolist()
    quantity_name_list=result_df['Quantity'].tolist()
    quantity_val_list=result_df['Value'].tolist()
    objval_list=result_df['ObjValue'].tolist()
    base_cost=result_df['BaseValue'].tolist()
    computeStamp_list = result_df['computeStamp'].tolist()
	
    No_rows = len(id_list)

    print 'writing results into database...'
    conn_string = "DRIVER={SQL Server};SERVER=" +db_server_name + ";DATABASE=" + db_name + ";UID=" + db_user_name + ";PWD=" + db_user_pwd
    conn = pyodbc.connect(conn_string)
    cursor = conn.cursor()
	
    insert_list = []
    for x in range(No_rows):
        row = [str(id_list[x]),str(timestamp_list[x]),str(quantity_name_list[x]),quantity_val_list[x],objval_list[x],base_cost[x],sharedComputeStamp]
        insert_list.append(row)
    cursor.executemany("insert into deroptciqsresult([ID], [Time Stamp], [Quantity], [Value],[ObjValue],[BaseValue],[computeStamp]) values (?, ?, ?, ?,?,?,?)", insert_list)
    conn.commit()

    insert_list = []
    for x in range(No_input_rows):
        row = [str(agg_dict['ID'][x]),str(agg_dict['Time Stamp'][x]),str(agg_dict['Quantity'][x]),agg_dict['Value'][x],sharedComputeStamp]
        insert_list.append(row)
    cursor.executemany("insert into input([ID], [Time Stamp], [Quantity], [Value],[computeStamp]) values (?, ?, ?, ?, ?)", insert_list)
    conn.commit()

    conn.close()
	
    print 'task completed!'
